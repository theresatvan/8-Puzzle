Theresa Van <br>
CS 4200-01  <br>
In van_theresa_4200p1 folder, run the command "javac Main.java" to build, then the command "java Main" to compile. When running the option "Generate test cases", the csv file "testCases.csv" will be created containing test case results.